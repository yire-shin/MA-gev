cov.dir = function(wtgd){

  numk=length(wtgd)
  D=matrix(NA, numk, numk)
  for(i in 1:numk) D[i,i] = wtgd[i]*(1-wtgd[i])/2
  for(i in 1:(numk-1)){
    for(j in (i+1):numk){
      D[i,j]= -wtgd[i]*wtgd[j]/2
      D[j,i]= D[i,j]
    }
  }
  return(D)
}
