cand.xi.new.paper <- function(data, mle=NULL, pick0=.95, nint=256,
                              start='mle', numk=NULL, figure=T){

  wx = list()   # mle= mle.hosking in the input
  SMALL= 1e-05
  #  numk= hosking$numk
  #  start = 'mle'
  kpar=rep(NA, numk)
  move=F

  while(start=='mle' | start=='mix'){

    newse= max(0.3,abs(mle[3]))*0.2

    mle.coles= mle
    mle.coles[3]= -mle[3]

    xlow= mle.coles[3]-25*newse; xup=  mle.coles[3]+12*newse
    xlow= max(-0.99, min(0.5,xlow), na.rm=T)
    xup=  min(0.99, max(-0.5,xup), na.rm=T)
    xlow2 = min(xlow, xup); xup2 = max(xlow, xup)

    pilo= (1-pick0)/2; piup =1-pilo
    eqpr = seq(pilo, piup, by=pick0/(numk-1) )
    numpi=floor(numk/2)
    pipick=rep(NA,numpi)

    pipick[1]=pick0
    for (i in 2:numpi){ pipick[i] = 1- 2*eqpr[i]}

    get.ci = gev.profxi.mdfy.paper(data, mle=mle.coles,
                                   xlow=xlow2, xup= xup2,
                                   pick.v=pipick, nint=nint, figure=figure)

    if(get.ci$fail==T) {
      start='lme'; move=T
      break
    }

    wx$get.ci = get.ci

    lo.lim =min(-get.ci$w1$ci1[1], -get.ci$w1$ci2[1])
    up.lim =max(-get.ci$w1$ci1[1], -get.ci$w1$ci2[1])

    kpar[1] = max(lo.lim, -0.99)
    kpar[numk] = min(up.lim, 0.99)

    if(is.odd.me(numk)) kpar[floor(numk/2)+1] = -get.ci$w1$xmax

    for(i in 2:numpi){
      lo.lim =min(-get.ci$w1$ci1[i], -get.ci$w1$ci2[i])
      up.lim =max(-get.ci$w1$ci1[i], -get.ci$w1$ci2[i])
      kpar[i]= max(lo.lim, -0.99)
      kpar[numk-i+1]= min(up.lim, 0.99)
    } #end for

    if(kpar[numk] < -0.3) {
      kpar2=rep(NA,numk+2)
      kpar2[numk+1]= max(-0.3, kpar[numk]+0.05)
      kpar2[numk+2]= max(-0.3, kpar2[numk+1]+0.05)
      kpar[1:numk] =c(kpar[3:numk], kpar2[numk+1], kpar2[numk+2])
    }

    wx$kpar.mle = kpar
    break
  } # end while

  #-------------------------------------------------------
  if(start=='lme' | start=='mix') {

    # lo.lim= quantile( hosking$lme.boot[,3], prob=(1-pick)/2, na.rm=T)
    # up.lim= quantile( hosking$lme.boot[,3], prob=1-(1-pick)/2, na.rm=T)
    # lo.lim= max(-.9999, lo.lim)

    pilo= (1-pick)/2; piup =1-pilo
    eqpr = seq(pilo, piup, by=pick/(numk-1) )

    if(!is.null(cov.lme)){
      hosking$lme.boot = cov.lme$lme.boot

    }else{

      if(hosking$boot.lme ==F & move==T){
        Bnew=hosking$B; qua= hosking$quant

        hosking = lme.boots.new(data=data, B=Bnew, quant=qua,
                                boot=T)
      }
    } #end if

    kpar = quantile( hosking$lme.boot[,3], prob=eqpr, na.rm=T)

    if(kpar[numk] < -0.5) kpar[numk]= max(-0.5, kpar[numk]+0.05)
    wx$kpar.lme = kpar
    if(move==T) wx$kpar.mle = kpar
    hosking$start=start
  }

  if(start=='mix'){
    wx$kpar.mix = (wx$kpar.mle + wx$kpar.lme)/2
  }

  if(start=='mle') {kpar = wx$kpar.mle
  }else if(start=='lme') {kpar = wx$kpar.lme
  }else if(start=='mix') {kpar = wx$kpar.mix
  }
  if( any(abs(kpar) <= SMALL)) {
    kpar[ which(abs(kpar) <= SMALL) ] = SMALL*1.2 }

  if(kpar[numk] >= 0.5) kpar[numk]= 0.49
  wx$kpar = kpar
  wx$start = start
  if(start=='mle') wx$ymin = get.ci$ymin

  return(wx)
}
