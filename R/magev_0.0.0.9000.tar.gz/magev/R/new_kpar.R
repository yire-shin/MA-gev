new.kpar = function(wtgd, numk, kpar, final){

  wtgd[which(is.na(wtgd))] =0
  zp=list()
  aw=0
  dist=0.03

  nid = which(wtgd < 0.01); id = which(wtgd >= 0.01)
  kpar = kpar[id]
  wtgd = wtgd[id]
  numk2 = length(kpar); if(numk2 < numk) aw=10 ; numk = numk2
  kpar2= kpar

  if(numk==0) {
    kpar2= -0.1
    numk=1
  }

  if(numk==1){
    ad=1.5
    kpar2= c(NA,NA, kpar2, NA,NA)
    kpar2[2]= max(kpar2[3] -dist/ad,   -0.99)
    kpar2[1]= max(kpar2[3] -2*dist/ad, -0.99)
    kpar2[4]= min(kpar2[3] +dist/ad,   0.49)
    kpar2[5]= min(kpar2[3] +2*dist/ad, 0.49)
    aw=11

  }else{

    tre1=0.1; tre8=0.8

    work1=0; work2=0

    if(wtgd[1] >= tre1 & wtgd[1] <= tre8) {
      kpar2= c(rep(NA,2), kpar)
      kpar2[2] = max(kpar[1]-dist, -0.99)
      kpar2[1] = max(kpar2[2]-dist, -0.99)
      work1=1
    }else if(wtgd[1] > tre8) {
      kpar2= c(rep(NA,4), kpar)
      kpar2[4] = max(kpar[1]-dist/2, -0.99)
      kpar2[3] = max(kpar2[4]-dist/2, -0.99)
      kpar2[2] = max(kpar2[3]-dist/2, -0.99)
      kpar2[1] = max(kpar2[2]-dist/2, -0.99)
      work1=2
    }

    if(work1==0 & wtgd[numk] >= tre1 & wtgd[numk] <= tre8){
      kpar2= c(kpar, rep(NA,2))
      kpar2[numk+1]= min(kpar2[numk]+dist, 0.49)
      kpar2[numk+2]= min(kpar2[numk+1]+dist, 0.49)
      work2=1
    }
    if(work1==0 & wtgd[numk] > tre8){
      kpar2= c(kpar, rep(NA,4))
      kpar2[numk+1]= min(kpar2[numk]+dist/2, 0.49)
      kpar2[numk+2]= min(kpar2[numk+1]+dist/2, 0.49)
      kpar2[numk+3]= min(kpar2[numk+2]+dist/2, 0.49)
      kpar2[numk+4]= min(kpar2[numk+3]+dist/2, 0.49)
      work2=2
    }

    if(work1==1 & wtgd[numk] >= tre1){
      kpar2= c(kpar2,rep(NA,2))
      kpar2[numk+3]= min(kpar2[numk+2]+dist, 0.49)
      kpar2[numk+4]= min(kpar2[numk+3]+dist, 0.49)
      work2=2
    }

    aw= aw+ work1+work2

  } #end if numk =1

  numk=length(kpar2)

  zp$kpar2=kpar2
  zp$aw=aw
  zp$numk=numk
  return(zp)
}
