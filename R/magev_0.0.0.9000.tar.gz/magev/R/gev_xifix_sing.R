gev.xifix.sing =function (xdat, xifix= -0.1, ntry=5, varcom=NULL)
{
  zx <- list();  kx =list(); value=list()
  #  truepar=rep(0,2)

  init.xi= matrix(0, nrow=ntry, ncol=2)

  init.xi <- ginit.xifix(xdat, ntry)
  xi=xifix

  upsig= EnvStats::iqr(xdat)*5
  upmu=  abs(median(xdat))*3

  #  par.start=rep(1,2)

  tryCatch(
    for(itry in 1:nrow(init.xi)){

      #      par.start[1:2]=init.xifix[itry,1:2]

      value <- try(optim(init.xi[itry,], fn=gev.xilik,
                         lower =c(-upmu,0), upper =c(upmu,upsig),
                         method="L-BFGS-B",
                         xifix=xifix, xdat=xdat) )
      # control=list(trace=1, outer.iter=40,
      #              inner.iter=200, tol=1.e-5,
      #              delta=1.e-6) ))

      if(is(value)[1]=="try-error"){
        kx[[itry]] <- list(value=10^6)
      }else{
        kx[[itry]] <- value
      }

    } #for
  ) #tryCatch

  optim_value  <-data.frame(num=1:ntry,value=sapply(kx, function(x) x$value[which.min(x$value)]))

  optim_table1 <-optim_value[order(optim_value$value),]
  selc_num  <- optim_table1[1,"num"]

  x  <- kx[[selc_num]]

  zx$conv <- x$convergence
  zx$nllh <- x$value[which.min(x$value)]

  if(zx$conv != 0){
    zx$mle = NA
  }else{
    zx$mle <- x$par
    zx$mle[3]= xifix
    #     zx$grad <- numDeriv::grad(gev.xilik, x$par, xifix=xifix, xdat=xdat)
    if(varcom==T){
      Hess = PrescottW(x$par, xifix=xifix, nsam=length(xdat))
      #numDeriv::hessian(gev.xilik, x$par, xifix=xifix, xdat=xdat)
      if(is.na(Hess[1,1])) {
        zx$cov =matrix(NA,2,2)
      }else if(det(Hess) <= 0) {
        zx$cov =matrix(NA,2,2)
      }else{
        zx$cov <- solve(Hess)
      }
    } #end if varcom
  }
  class(zx) <- "gev.xifix"
  return(zx)
  invisible(zx)
}
