cov.interp.new = function(numk,para3,cov2=NULL){

  cov22 = array(NA,c(2,2,numk))

  for(ik in 1:numk){
    cov22[,,ik] = cov2[[ik]]   #mywt$prob.call$cov2[[ik]]
  }

  id= which(!is.na(cov22[1,1,]))
  id.na = which(is.na(cov22[1,1,]))
  if(length(id.na)==numk) stop("all cov22 are NA")

  if( length(id) < numk){

    cat("Need cov interpolation because some cov are NA",
        "id for cov interpol=",id.na,"\n")

    xsp = para3[id,3]; y1= cov22[1,1,id]
    y2= cov22[2,2,id]
    y12= cov22[1,2,id]

    covint = matrix(NA,3,numk)
    covint[1,id.na]= spline(x=xsp, y1, method="natural",
                            xout=para3[id.na,3])$y
    covint[2,id.na]= spline(x=xsp, y2, method="natural",
                            xout=para3[id.na,3])$y
    covint[3,id.na]= spline(x=xsp, y12, method="natural",
                            xout=para3[id.na,3])$y

    cov22[1,1,id.na]= covint[1,id.na]
    cov22[2,2,id.na]= covint[2,id.na]
    cov22[1,2,id.na]= covint[3,id.na]
    cov22[2,1,id.na]= covint[3,id.na]

  } #end if
  return(cov22)
}
