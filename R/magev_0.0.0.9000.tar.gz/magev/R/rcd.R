rcd = function(xi){

  minxi = -0.2
  nxi=length(xi)
  pfxi=rep(NA, nxi)

  for(i in 1:nxi){
    if( is.na(xi[i]) | is.null(xi[i]) ){
      pfxi[i]=0
    }else{
      if( -1.0 < xi[i] & xi[i] <= minxi) {
        b1= -1/(1+minxi)
        b0= 1-b1*minxi

        pfxi[i] = b0+b1*xi[i]
      }
    } #end if
    if( xi[i] <= -1.0 | xi[i] > minxi) pfxi[i]=1
  } #end for
  return(pfxi)
}
