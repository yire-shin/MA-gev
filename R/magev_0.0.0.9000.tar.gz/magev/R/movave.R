movave= function(order,numk,numq, zp, wt=NULL){

  za=list()
  q=order
  ez=matrix(NA,numq,numk);  ew=rep(NA,numk)

  if(numk >= (q+1)){
    for (ip in 1:numq){
      ez[ip,]=zoo::rollmean(zp[ip,1:numk], q, fill="extend",align="center")
    }
  }else if(numk <= q){
    for(ip in 1:numq){
      for(ik in 1:numk){
        ez[ip,ik] = mean(zp[ip,1:numk])
      }
    }
  } #end if

  if(numk >= (q+1)){
    ew = zoo::rollmean(wt,q,fill="extend",align="center")

  }else if(numk <= q){
    for(ik in 1:numk){
      ew[ik] = mean(wt[1:numk])
    }
  } #end if
  za$ez =ez; za$ew=ew
  return(za)
}
