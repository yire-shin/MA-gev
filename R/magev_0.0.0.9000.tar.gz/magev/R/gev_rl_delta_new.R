gev.rl.delta_new <- function(data, ntry=5, quant){

  zg=list()
  numq=length(quant)
  # names_par= c("mu","sigma","shape")
  # names_quant=paste("q",as.character(quant[1:numq]),sep="")

  kmle.h = gev.max(data, ntry=ntry)
  #   if(abs(kmle.h$mle[3]) >= 0.4 ) kmle.h$mle[3] = sign(kmle.h$mle[3])*0.4

  kmle.coles = ismev::gev.fit(data, show=F)

  if(kmle.h$nllh < kmle.coles$nllh) {

    if(abs(kmle.h$mle[3]) >= 0.49 ) kmle.h$mle[3] = sign(kmle.h$mle[3])*0.49
    better=  tryCatch( ismev::gev.fit(data, show=F, muinit=kmle.h$mle[1],
                               siginit=kmle.h$mle[2], shinit= -kmle.h$mle[3])
    )
    # we need the above computing to obtain covariance

    better.mle = better$mle
    better.mle[3]= -better$mle[3]

  }else{
    better = kmle.coles
    better.mle= kmle.coles$mle
    better.mle[3]= -kmle.coles$mle[3]
  }

  if(abs(better.mle[3]) >= 1) {
    #    cat("gev.rl.delta_new: mle less than -1.0 =", better.mle[3],"\n")
    better.mle[3]= sign(better.mle[3])*0.98
  }

  savem= lmomco::vec2par(better.mle,'gev')
  zg$nllh = better$nllh
  zg$mle = better.mle
  zg$qua.mle= lmomco::quagev(quant[1:numq],savem)
  zg$data = data
  zg$cov= better$cov

  # names(zg$qua.mle)=names_quant
  # names(zg$mle)=names_par
  zg$quant=quant
  return(zg)
}
