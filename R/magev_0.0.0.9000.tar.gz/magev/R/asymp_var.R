asymp.var =  function(mywt, covint, qqq=NULL, order=2){

  zx=list(); consC=list()
  wtgd= mywt$wtgd; bmaw = mywt$bmaw
  numq=length(qqq); numk = length(wtgd)
  zp=mywt$zp

  consC = cons.MatC(mywt, covint, quant=qqq)

  zx$fin.se.MA.qua = consC$fin.se
  zx$fin.se.bma.qua = consC$fin.se.bma

  ezvar=rep(NA,numq); ewvar=rep(NA,numq); ewvar.bma=rep(NA,numq)
  trCD=rep(0, numq); trCD.bma=rep(0, numq)

  D = cov.dir(wtgd)
  Dbma = cov.dir(bmaw)

  move= movave(order, numk, numq, zp, wt=wtgd)
  ez=move$ez
  ew= move$ew

  moveb= movave(order, numk, numq, zp, wt=bmaw)
  ewbma= moveb$ew

  for(ip in 1:numq){
    ezvar[ip]= t(ez)[,ip] %*% D %*% ez[ip,]
    ewvar[ip]= t(ew) %*% consC$MatC[,,ip] %*% ew
    ewvar.bma[ip]= t(ewbma) %*% consC$MatC[,,ip] %*% ewbma

    trCD[ip]= sum( diag(consC$MatC[,,ip] %*% D) ) + ezvar[ip]
    trCD.bma[ip]= sum( diag(consC$MatC[,,ip] %*% Dbma) ) + ezvar[ip]
  }
  # zx$adj.se.MA.qua = sqrt(consC$fin.se^2 + trCD )
  # zx$adj.se.bma.qua = sqrt(consC$fin.se.bma^2 + trCD.bma)

  zx$adj.se.MA.qua = sqrt(ewvar + trCD )
  zx$adj.se.bma.qua = sqrt(ewvar.bma + trCD.bma)

  zx$MatC = consC$MatC

  # zx$ew.adj.se.MA.qua = sqrt(consC$ew.fin.se^2 + trCD )
  # zx$ew.adj.se.bma.qua = sqrt(consC$ew.fin.se.bma^2 + trCD.bma)
  return(zx)
}
