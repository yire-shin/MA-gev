PrescottW = function(par2=NULL, xifix=NULL, nsam=NULL){

  #   mu=par2[1]
  sig=par2[2]
  xi=xifix
  Hess=matrix(NA,2,2)

  if(xi < 0.5){
    pw= (1-xi)^2 * gamma(1-2*xi)
    Hess[1,1] = nsam*pw/(sig^2)
    Hess[2,2] = nsam*(1-2*gamma(2-xi)+pw)/(sig^2 * xi^2)
    Hess[1,2] = nsam*(pw-gamma(2-xi))/(sig^2 * xi)
    Hess[2,1] = Hess[1,2]
  }else{
    cat("FIM is not available because xi >= 0.5","\n")
  }
  return(Hess)
}
