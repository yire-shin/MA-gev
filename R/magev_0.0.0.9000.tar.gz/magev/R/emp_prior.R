emp.prior = function(mle3, mle, lme){

  z=list()
  xi= mle3[,3]
  nxi=length(xi)
  pfxi=rep(NA, nxi);  pfmu=rep(NA, nxi);  pfsig=rep(NA, nxi)

  mnx= min(mle[3],lme[3]); mxx=max(mle[3],lme[3])
  u= -0.6; u0= -0.0;

  if(mxx <= u) {pfxi=1; return(pfxi)}
  if(mnx <= u) {mnx=u+0.05; b=0}
  else{ b= 1/(mnx-u-u0)}
  b2=1/(mnx-u-u0)

  for(i in 1:nxi){
    if( is.na(xi[i]) | is.null(xi[i]) ){
      pfxi[i]=0
    }else{
      if( u+u0 < xi[i] & xi[i] < mnx) {
        pfxi[i] = (xi[i] -u-u0)*b
      }else if(mnx <= xi[i] & xi[i] <= mxx) {
        pfxi[i] = 1
      }else if( mxx < xi[i] & xi[i] < mxx+mnx-u){
        pfxi[i] = 1 +(mxx-xi[i])*b2
      }else if( xi[i] <= u+u0 | xi[i] >= mxx+mnx-u) {pfxi[i]=0
      }
    } #end if
  } #end for

  return(pfxi)
}
