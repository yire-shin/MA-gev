#' @name ma.gev.open
#' @aliases ma.gev.open
#' @title model averaging with mixed criterion for estimating high quantile in the GEVD.
#' @description The method in this code combines MLE and LME to construct candidate submodels and assign weights effectively, applied to generalized extreme value distribution.
#' @param data A numeric vector of data to be fitted.
#' @param quant The probabilities corresponding to high quantiles to be estimated. For example, quant=c(.90,.95,.98,.99,.995,.998)
#' @param weight The weighting method name; choice of weight = 'gLd', 'med', 'like', and 'cvt'(=conventional), and 'gLd1', 'gLd2', 'like0'(default), 'like1', 'med1', 'med2'
#' @param numk The number of submodels, K (default=12)
#' @param B The number of bootstrap samples (default=200).
#' @param varcom Whether or not to compute the variance of quantile estimation; It has value of T (default) or F.
#' @param trim The number of left trimming, usually 0 (default), 1, or 2.
#'
#' @return {
#'  A list containing the following components. Some of these components are printed after the fit, depending on the input options.
#'
#'  \item{mle.hosking}{A vector containing the mle in hosking style (different sign for the shape parameter from Coles book.)}
#'  \item{qua.mle}{The quantile estimates from mle.}
#'  \item{mle.cov3}{The covariance matrix of the mles of three parameters, obtained from the Fisher info matrix.}
#'  \item{qua.se.mle.delta}{A vector containing the standard errors of quantile estimate obtained from mle, using the delta method.}
#'  \item{lme}{A vector containing the lme.}
#'  \item{lme.cov3}{The covariance matrix of the lmes of three parameters, obtained by bootstrap.}
#'  \item{qua.lme}{The quantile estimate from the lme}
#'  \item{qua.se.lme.boots}{A vector containing the standard errors of quantile estimate obtained from lme, using bootstrap.}
#'  \item{leftrim}{Number of left trim.}
#'  \item{data}{The data that has been fitted. For non-stationary models, the data is standardized.}
#'  \item{fin.se.ma}{A vector containing the asymptotic SE of quantile estimates under fixed weights.}
#'  \item{adj.se.ma}{A vector containing the asymptotic SE of quantile estimates under random weights.}
#'  \item{surr_par}{Parameters for surrogate model.}
#'  \item{zp}{A matrix containing the quantile estimates from each submodel.}
#'  \item{zp.ma}{The quantile estimates from MA of K submodels.}
#'  \item{w.ma}{A vector containing the weights used for MA.}
#'  \item{pick_xi}{A vector containing xi_k for K submodels, selected based on the 95 percentage confidence interval of xi.}
#' }
#' @seealso \code{\link{lmoms}}
#' @export
#'
#' @examples
#' \dontrun{
#' data(haenam)
#' ma.gev.open(data=haenam, quant=c(.98, .99, .995), weight='like0')
#' }
ma.gev.open= function(data=NULL, quant=c(.95,.98,.99,.995), weight='like0',
                      numk=12, B=200, varcom=T, trim=0)
{

  # start.est = 'mle' (default) or 'lme'
  # pick: CI level between .90 or .95 (default)
  # choice of weight = 'gLd', 'med', 'like', and cvt' (=conventional mle and aic weight)
  #                    'gLd1', 'gLd2', 'like0', 'like1', 'med1', 'med2'

  zx=list()
  SMALL <- 1e-05
  numq=length(quant)

  # defaults
  start='mle'; pick=.95; pertr=0.85; surr=T; fcv.work=F;
  try.last=F; fig=F; numom=3; order=3; boot.lme=T; cov.lme=NULL; type='full'
  seek=F; cov.type='lambda';  fix.kpar=F; pick.xi=NULL;

  if(fix.kpar==F) {pick.xi=NULL
  }else if(fix.kpar==T) {numk= length(pick.xi)}
  if(surr==F) fig=F
  if(fig==T) {surr=T; boot.lme=T; varcom=T}
  if(weight=='gld') weight='gLd'
  if(cov.type=='r') cov.type='ratio'
  if(cov.type=='l') cov.type='lambda'
  if(weight=='like0'){weight='like'; trim=0}
  if(weight=='like1'){weight='like'; trim=1}
  if(weight=='gld1' | weight=='gLd1'){weight='gLd'; trim=1}
  if(weight=='gld2' | weight=='gLd2'){weight='gLd'; trim=2}
  if(weight=='med1'){weight='med'; trim=1}
  if(weight=='med2'){weight='med'; trim=2}

  zx$weight = weight
  zx$data= data
  org.numk=numk

  if(fcv.work==T) {    # using for the forward cross-validation for upper 100*pertr%
    ccv = cons.dte(data,pertr, type='full')
    data= ccv$dtr
    nsam= length(data)
  }

  para3= matrix(NA,nrow=numk, ncol=3)
  wtgd= rep(NA, numk)
  zp= matrix(NA, numq, numk)
  zpf=rep(NA, numq)

  nsample=length(data)
  delta=list()

  # ------- mle and se by delta method-------------------

  delta= gev.rl.delta_new(data=data, ntry=10, quant=quant)

  zx$mle.hosking =  delta$mle
  zx$qua.mle= delta$qua.mle
  zx$mle.cov3 = delta$cov
  #  zx$mle.aic = delta$nllh*2 + 2*3

  if(varcom==T & !is.null(delta$cov) ){
    qua.se.mle=rep(NA, numq)
    for(i in 1:numq){
      qua.se.mle[i]= delta.gev(gevf3= delta,quant=quant[i],d3yes=T)$v3
    }
    zx$qua.se.mle.delta = sqrt(qua.se.mle)
  }

  #-----  Lme and se by bootstrap --------------------
  if(is.null(cov.lme)){
    if(start=='lme' |weight=='med' |start=='mix'
       | weight=='lcv' | weight=='opt') boot.lme=T
  }

  hosking=list()
  hosking = lme.boots.new(data=data, B=B, quant=quant,
                          boot=boot.lme, trim=trim)

  if(boot.lme==T) {zx$lme.cov3 = hosking$cov.par
  }else if(boot.lme==F){zx$lme.cov3 = cov.lme$cov.par}

  zx$lme = hosking$lme
  zx$qua.lme= hosking$qua.lme; zx$leftrim=trim
  hosking$mle = delta$mle

  xi.hat = (delta$mle[3] + hosking$lme[3])/2
  #  if(xi.hat > 0.0) {cat("no need to do MA computing, xi.hat=",
  #                        xi.hat,"\n")}

  # if(try.last==TRUE | try.last==T){
  # # ---- mple CD, re.mle, mpse  ------------------------------------------
  #   CD.mle= rep(NA,3)
  #   CD.mle= gev1.CD.hos(xdat=data, ntry=5)$mle  # hosking style xi
  #
  #   if(any(is.na(CD.mle)) ) {
  #     zx$qua.CD=NA; zx$mle.CD =NA; CD.mle=NULL
  #   }else{
  #     zx$qua.CD = quagev(quant, vec2par(CD.mle,'gev'))
  #     zx$mle.CD = CD.mle
  #   }
  #
  #   rem.try=list()
  #   rem.try = gev.remle(xdat=data, ntry=5, rest='mean', quant=quant,
  #                       trim=0, CD.mle=CD.mle, mle=delta$mle,
  #                       second=T, w.mpse=F)
  #
  #   zx$remle1 = rem.try$remle1
  #   zx$qua.remle1 = rem.try$qua.remle1
  #   zx$remle2 = rem.try$remle2
  #   zx$qua.remle2 = rem.try$qua.remle2
  #   zx$qua.rem.ave = (zx$qua.remle1 + zx$qua.remle2)/2
  #
  #   zx$mpse = rem.try$mpse
  #   zx$qua.mpse = rem.try$qua.mpse
  # }
  # # --------------------------------------------------------------

  hosking$start = start; hosking$numk = numk; hosking$quant=quant
  hosking$weight = weight; hosking$B= B; hosking$trim=trim
  hosking$data = data; hosking$boot.lme = boot.lme

  #---  xi_k picking for cand submodels ---------------------------
  kpar=rep(NA, numk)

  if(fix.kpar==F){
    kpar.list=list()

    kpar.list = cand.xi.new.paper(data, mle=zx$mle.hosking,
                                  pick0=pick, nint=256, start=start,
                                  numk=numk, figure=fig)

    kpar = kpar.list$kpar
    hosking$start= kpar.list$start

  }else if(fix.kpar==T){
    kpar=pick.xi
    hosking$start=start
  }
  hosking$kpar = kpar; hosking$cov.type= cov.type

  #------- Zp and weights computing-----------------------------------
  run=1;

  xqa=c(0.5, .65, .8, .85, .9, .925, .95, .965,.98,
        .985, .99, .9925, .995, .9965, .998, .999)
  mywt=list()
  hosking$pertr = pertr
  bmaw=rep(NA, numk); wtgd=rep(NA, numk); bmaw2=rep(NA, numk);

  mywt = weight.com.new(data, numk=numk, hosking, kpar, numom=numom,
                        xqa, varcom=varcom, boot.lme=boot.lme,
                        cov.lme, surr=surr,
                        type, trim=trim, cov.type=cov.type)

  para3 = mywt$prob.call$mle3;
  npara3= na.omit(para3); numk=nrow(npara3);
  notid= which(!is.na(para3[,1]))
  mywt$data = data; para3=npara3; mywt$prob.call$mle3 = npara3
  kpar= kpar[notid];

  zp = mywt$zp[,notid];  xzp = mywt$xzp[,notid]
  wtgd = mywt$wtgd[notid]; mywt$wtgd = wtgd
  bmaw = mywt$bmaw[notid]

  if(fix.kpar==F){

    final=F
    newk= new.kpar(wtgd, numk, kpar, final)

    numk= newk$numk
    aw=newk$aw
    while(aw >= 1){

      run=run+1
      kpar=newk$kpar2
      hosking$kpar = newk$kpar2; hosking$numk = numk

      mywt=list()
      bmaw=rep(NA, numk); wtgd=rep(NA, numk)
      para3= matrix(NA, nrow=numk, ncol=3)
      zp= matrix(NA, numq, numk)

      mywt = weight.com.new(data, numk=numk, hosking, kpar=newk$kpar2, numom=numom,
                            xqa, varcom=varcom, boot.lme=boot.lme,
                            cov.lme, surr=surr,
                            type, trim=trim, cov.type=cov.type)

      para3 = mywt$prob.call$mle3
      npara3= na.omit(para3); numk=nrow(npara3);
      notid= which(!is.na(para3[,1]))
      mywt$data = data; para3=npara3; mywt$prob.call$mle3 = npara3
      kpar= kpar[notid];

      zp = mywt$zp[,notid];  xzp = mywt$xzp[,notid]
      wtgd = mywt$wtgd[notid]; mywt$wtgd = wtgd
      bmaw = mywt$bmaw[notid]; bmaw2 = mywt$bmaw2[notid]

      if(run >= 2) break
      mxid = which.max(wtgd)
      if(wtgd[1] > 0.02 | wtgd[numk] > 0.02 | wtgd[mxid] > 0.7){
        newk= new.kpar(wtgd, numk, kpar,final)
        numk= newk$numk
        aw=newk$aw
      }else{ aw=0; break}
    } #end while

  } # end if fix.kpar

  idp3 = which( is.na(para3[,1]) )
  para3[idp3,]=0; wtgd[idp3]=0; bmaw[idp3]=0

  id= which( is.na(t(zp)[,1]) )
  zp[,id]=0; wtgd[id]=0; bmaw[id]=0
  if( all(wtgd==0) ) {
    cat("==== all RL are NA ====")
    zx$zp.ma = zx$qua.lme;  zx$zp.bma = zx$qua.lme; return(zx)
  }

  bmaw[which(is.na(bmaw))]=0.0;
  wtgd[which(is.na(wtgd))]=0.0

  zpf=rep(NA, numq);zpf.bma=rep(NA, numq)
  for (iq in 1:numq){
    zpf[iq]= t(wtgd) %*% t(zp)[1:numk,iq]
    zpf.bma[iq] = t(bmaw) %*% t(zp)[1:numk,iq]
  }

  # ---- calculating asymptotic SE by delta method -----------------

  if(varcom==T ){
    # ---- cov interpolation using spline, for NA cov cases ---
    covint =cov.interp.new(numk, para3, cov2=mywt$prob.call$cov2)

    #---asymptotic variance matrix MatC and asymp var of MA ---------

    avar = asymp.var(mywt, covint, qqq=quant, order)

  }      # end if varcom=T and if not 'like' weight

  #----- finding surrogate for MA using gev -----------
  if(surr==T){
    zpf.surr = t(wtgd)%*%t(xzp)
    para.ma= t(wtgd)%*% para3
    surro= surrogate(zpf.surr, xqa, init.surr= para.ma)
    zx$surr$par = surro$par
  }

  # ----- Predictive posterior variance ----------------

  if(varcom==T ){
    zpdiff= matrix(NA, numq, numk); loc.var= matrix(NA, numq, numk)
    for(ip in 1:numk){
      zpdiff[1:numq,ip]= (zp[1:numq,ip]-zpf.bma[1:numq])^2
      loc.var[1:numq,ip] = avar$MatC[ip,ip,1:numq]
    }
    msm = t(wtgd) %*% t(zpdiff)  # mean square of zp due to candidate models
    mse = t(wtgd) %*% t(loc.var)
  } # end if

  if(varcom==T ){
    zx$fin.se.ma =  avar$fin.se.MA.qua
    zx$adj.se.ma =  avar$adj.se.MA.qua
    #    zx$pred.se.ma = sqrt(msm + mse)
    #{pred.se.ma}{A vector containing the Bayesian predictive SE of quantile estimates.}
  }
  if(boot.lme==T){ zx$qua.se.lme.boots = hosking$qua.lme.se
  }else{zx$qua.se.lme.boots = cov.lme$qua.lme.se}

  # ------- finalization ---------------------------
  zx$zp= zp
  zx$zp.ma = zpf
  zx$w.ma = wtgd
  zx$pick_xi = kpar
  zx$numk = numk;

  return(zx)
}
