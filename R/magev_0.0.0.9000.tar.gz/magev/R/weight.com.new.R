weight.com.new <- function(data, numk=NULL, hosking, kpar=NULL, numom=3,
                           xqa=NULL, varcom=T, boot.lme=T, cov.lme=NULL, surr=F,
                           type='full', trim=NULL, cov.type='ratio'){

  z=list();
  quant = hosking$quant; weight = hosking$weight

  if(surr==T) { nxq = length(xqa)
  xzp= matrix(NA,nrow= nxq, ncol=numk) }
  numq= length(quant)

  B = hosking$B;
  start = hosking$start
  zp= matrix(NA, nrow=numq, ncol=numk)
  wtgd=rep(NA,numk); bmaw=rep(NA,numk); bmaw2=rep(NA,numk)
  prob.call=list()

  prob.call = dist.noboot(data, numk=numk, hosking=hosking, boot.lme=boot.lme,
                          kpar=kpar, numom=numom, ntry=5,varcom=varcom,
                          cov.lme=cov.lme, trim=trim, cov.type=cov.type)

  notid= which(!is.na(prob.call$mle3[,1]))
  prob.call$mle3= prob.call$mle3[notid,] ; mle3 = prob.call$mle3
  numk=length(notid)

  kpar=kpar[notid]
  prior= rcd(kpar)
  lme=hosking$lme; mle= hosking$mle
  eprior = emp.prior(mle3=mle3, mle=mle, lme=lme)

  eprior[which(is.na(eprior))]=0
  if(all(eprior==0)) eprior=1

  if(weight=='gLd' | weight=='med' | weight=='cvt' |weight=='fcv' ){

    if(varcom==T | weight=='fcv'){
      cov2=list()
      for(id in 1:numk){ cov2[[id]]= prob.call$cov2[[ notid[id] ]] }
    }

    if(weight == 'cvt') {

      naic= prob.call$aic[notid]
      id= which(is.na(naic));# nid = which(!is.na(naic))

      amin =naic -min(naic, na.rm=T)
      wtgd =exp(-amin)/sum( exp(-amin), na.rm=T)
      wtgd[id]=0

      bmaw = prior*exp(-amin)/sum( prior*exp(-amin), na.rm=T)
      bmaw[id]=0

      bmaw2 = eprior*exp(-amin)/sum( eprior*exp(-amin), na.rm=T)
    }

    if(weight == 'gLd' | weight == 'med' | weight=='fcv'){

      if(weight=='gLd') {kcol=1} else if(weight=='med') {kcol=2}
      if(weight=='fcv') {kcol=3}

      prob.mtx= prob.call$prob.mtx[notid,]
      wtgd[1:numk]= prob.mtx[1:numk,kcol]/sum(prob.mtx[,kcol], na.rm=T)

      #      pr.ms = psigma(par=prob.call$mle3[,1:3])

      bmaw[1:numk] = prior*prob.mtx[1:numk,kcol]/sum(prior*prob.mtx[,kcol], na.rm=T)

      bmaw2[1:numk] = eprior*prob.mtx[1:numk,kcol]/sum(eprior*prob.mtx[,kcol], na.rm=T)

    }  # end if

  } #end if weight

  if(weight=='lcv' | weight=='like' | weight=='opt'){

    pertr=hosking$pertr

    if(weight=='lcv' | weight=='like'){

      prob.call= wlik.xifix(data, numk=numk, kpar=kpar, weight=weight,
                            pertr, varcom, type, eprior, trim= trim) # note that trim=0

      if(varcom==T){ cov2=list()
      for(id in 1:numk){ cov2[[id]]= prob.call$cov2[[ notid[id] ]] }
      } #end if varcom
    }

    wtgd = prob.call$wt
    bmaw = prob.call$bmaw;  bmaw2 = prob.call$bmaw2
    prob.call$mle3 = t(prob.call$kfix)

    for (ip in 1:numk){
      save= lmomco::vec2par(prob.call$kfix[1:3,ip],'gev')
      zp[1:numq,ip]= lmomco::quagev(quant[1:numq],save)

      if(surr==T) xzp[1:nxq,ip]= lmomco::quagev(xqa[1:nxq],save)
    }   # end for ip

  }else{      #if(weight=='gLd' | 'med' | 'fcv' | 'cvt')

    for (ip in 1:numk){
      if( any( is.na(prob.call$mle3[ip,1:3]) ) ) {
        zp[1:numq,ip] = NA
        if(surr==T) xzp[1:nxq,ip] = NA
      }else{
        save= lmomco::vec2par( prob.call$mle3[ip,1:3],'gev' )
        zp[1:numq,ip]= lmomco::quagev(quant[1:numq],save)
        if(surr==T) xzp[1:nxq,ip]= lmomco::quagev(xqa[1:nxq],save)
      }
    }    # end for ip

  }  # end of if weight= 'lcv' or 'like'

  z$weight= weight
  z$wtgd= wtgd; z$bmaw = bmaw ; z$bmaw2= bmaw2
  z$zp=zp
  z$prob.call= prob.call
  if(varcom==T) {z$prob.call$cov2 = cov2
  }else{z$prob.call$cov2=NA}        # cov2[[ip]]: 2*2 cov-mat of (mu, sig)
  if(surr==T) z$xzp = xzp           # for fitting a surrogate gev model
  return(z)
}
