#' @export
lme.boots.new <-function(data, B=NULL, quant, boot=T, trim=NULL){

  z=list();  numq=length(quant)
  # names_par= c("mu","sigma","shape")
  # names_quant=paste("q", as.character(quant[1:numq]), sep="")
  sam.bootL=list()
  lme.boot =matrix(NA,nrow=B,ncol=3);  ratios =matrix(NA,nrow=B,ncol=3)
  lme.seboot =matrix(NA,nrow=B,ncol=numq); med = rep(NA, B)
  lambdas =matrix(NA,nrow=B,ncol=3)

  nsam=length(data); re=sort(data)
  lmt= lmomco::lmoms(data, nmom=3)
  klmet= lmomco::pargev(lmt, checkmom=T)
  z$lme = klmet$para[1:3]
  savet= lmomco::vec2par(klmet$para[1:3],'gev')
  z$qua.lme= lmomco::quagev(quant[1:numq],savet)

  z$quant = quant

  # names(z$qua.lme)=names_quant; names(z$lme)=names_par

  if(boot==T | boot==TRUE){
    for (ib in 1:B){
      sam.bootL[[ib]]= sample(data, nsam,replace=T)   # nonpara Boot

      lm.boot= lmomco::lmoms(sam.bootL[[ib]], nmom=3)

      lme.boot[ib,1:3]= lmomco::pargev(lm.boot, checklmom=F)$para[1:3]
      save=lmomco::vec2par(lme.boot[ib,1:3],'gev')
      lme.seboot[ib,1:numq]= lmomco::quagev(quant[1:numq],save)

      # if(trim > 0){
      #   lm.boot= TLmoms(sam.bootL[[ib]], nmom=3, leftrim=trim)
      # }

      lambdas[ib,1:3] = lm.boot$lambdas[1:3]
      ratios[ib,1]= lm.boot$lambdas[1]
      ratios[ib,2:3] = lm.boot$ratios[2:3]
      med[ib]= median(sam.bootL[[ib]])

    } # end for ib

    lme.bb = ratios
    lme.bb[1:B,1]= med[1:B]
    z$cov.med.rat= cov(lme.bb[,1:3])

    lme.bb = lambdas
    lme.bb[1:B,1]= med[1:B]
    z$cov.med.lam= cov(lme.bb[,1:3])

    z$cov.lambda = cov(lambdas[,1:3])

    z$B= B; z$lme.boot= lme.boot
    #z$ratios = ratios;  z$med = med; z$lambdas = lambdas

    z$cov.rat= cov(ratios[,1:3])
    z$cov.par= cov(lme.boot[,1:3])

    qua.lme.se=rep(NA, numq)
    for (qi in 1:numq){
      qua.lme.se[qi]=sqrt(var(lme.seboot[1:B,qi],na.rm=T))
    }
    z$qua.lme.se= qua.lme.se
    z$qua.lme.boot = lme.seboot

  }  #end if(boot==T)

  return(z)
}
