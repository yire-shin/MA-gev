comp.prof.ci.new = function(d, v, conf=NULL){

  w = list()
  numcf = length(conf)
  d$v = v
  w$vmax= max(d$v)
  nmsp = length(d$v)

  w$nllh  <- w$vmax    # -z$nllh
  idmax = which.max(d$v)
  w$xmax = d$x[idmax]

  ci1=rep(NA,numcf); ci2=rep(NA,numcf)
  ci_length=rep(NA,numcf)

  for(i in 1:numcf){

    chisq <- w$vmax - 0.5 * qchisq(conf[i], 1)
    diff  <- d$v - chisq

    ci1[i]   <- d$x[which.min(abs(diff[1:idmax]))]
    ci2[i]   <- d$x[(idmax+1):nmsp][which.min(abs(diff[(idmax+1):nmsp]))]

    ci_min =min(ci1[i], ci2[i])
    ci_max =max(ci1[i], ci2[i])
    ci1[i] =ci_min
    ci2[i] =ci_max

    if (ci2[i] < w$xmax) {
      cat("Routine fails, try changing plotting interval",
          fill = TRUE)
    }
    #  ci1_ci2[i] = c(ci1[i], ci2[i])
    ci_length[i] <- ci2[i]-ci1[i]
  } #end for i

  w$ci1=ci1; w$ci2=ci2;  w$ci_length=ci_length;

  return(w)
}
