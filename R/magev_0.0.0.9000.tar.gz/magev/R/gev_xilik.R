gev.xilik <- function(a, xifix=NULL, xdat=NULL) {

  mu <- a[1]      #mulink(mumat %*% (a[1:npmu]))
  sc <- a[2]      #siglink(sigmat %*% (a[seq(npmu + 1, length = npsc)]))
  # xi <- shlink(shmat %*% (a[seq(npmu + npsc + 1, length = npsh)]))

  xi=xifix
  if(sc <= 0) return(10^6)

  nsam= length(xdat)
  y= rep(0,nsam)
  y <- (xdat - mu)/sc
  y <- 1 - xi * y      # park modify to negative, for xi in hosking

  for (i in 1:nsam){
    y[i] = max(0, y[i], na.rm=T) }

  if (any(y <= 0)) return(10^6)
  if( abs(xi) >= 10^(-5) ) {ooxi= 1/xi
  }  else  {ooxi=sign(xi)*10^5}

  b2= sum(log(y)) * (1-ooxi)
  b3= sum(exp(ooxi * log(y)) )

  nllh =  nsam*(log(sc)) + b2 + b3

  zz=nllh
  return(zz)
}
