ginit.max <-function(data=NULL,ntry=NULL){

  if(ntry < 2) ntry=2
  n=ntry
  init <-matrix(NA,ntry,3)

  lmom_init = lmomco::lmoms(data,nmom=3)
  lmom_est <- lmomco::pargev(lmom_init)

  init[1,1]    <-lmom_est$para[1]
  init[1,2]    <-lmom_est$para[2]
  init[1,3]    <-lmom_est$para[3]

  maxm1=ntry; maxm2=maxm1-1
  init[2:maxm1,1] <- init[1,1]+rnorm(n=maxm2,mean=0,sd = 5)
  init[2:maxm1,2] <- init[1,2]+rnorm(n=maxm2,mean=3,sd = 3)
  init[2:maxm1,3] <- runif(n=maxm2,min= -0.45,max=0.4)
  init[2:maxm1,2] = max(0.1, init[2:maxm1,2])

  return(init)
}
