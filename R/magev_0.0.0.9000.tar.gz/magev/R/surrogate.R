surrogate = function(zpf.surr=NULL,xqa, init.surr){

  press.fun = function(par){
    theta=par
    if(theta[2] <= 0)  return(10^10)
    if(theta[3] <= -1.0 | theta[3] >= 1)  return(10^10)
    mzp= lmomco::quagev(xqa, lmomco::vec2par(theta, 'gev'))
    fun = sum((zpf.surr - mzp)^2)
    #fun = sum(abs(zpf.surr - mzp))
    return(fun)
  }

  surrx=list()
  surrx = optim(par=init.surr, fn=press.fun )  #, method="L-BFGS-B", lower=c(-Inf, 0, -1), upper=c(Inf, Inf, 1))

  surrx$zp.surrmodel = lmomco::quagev(xqa, lmomco::vec2par(surrx$par, 'gev'))
  surrx$zp.MA = zpf.surr
  return(surrx)
}
