cons.MatC = function(mywt, cov22, quant){

  numk= length(mywt$wtgd)
  numq= length(quant)
  MatC = array(NA, c(numk, numk, numq))
  cov2i= matrix(NA,2,2); cov2j=matrix(NA,2,2)

  para3 = mywt$prob.call$mle3

  for (i in 1:numk){
    mle3i= para3[i,]
    cov2i= as.matrix(cov22[,,i])         #mywt$prob.call$cov2[[i]]

    for (j in i:numk){
      mle3j = para3[j,]
      cov2j = as.matrix(cov22[,,j])      #mywt$prob.call$cov2[[j]]

      if( any(is.na(cov2i)) | any(is.na(cov2j)) ) {
        MatC[i,j,1:numq]=NA
      }else{
        MatC[i,j,1:numq]=delta.gev(gevf3=NULL, mle3i=mle3i, cov2i=cov2i,
                                   mle3j=mle3j, cov2j=cov2j,
                                   quant=quant, d3yes=F)$covij[1:numq]
        MatC[j,i,1:numq]= MatC[i,j,1:numq]
      } #end if
    } #end for j
  } #end for i

  wtgd = mywt$wtgd; bmaw = mywt$bmaw
  fin.se =rep(NA, numq); fin.se.bma =rep(NA, numq)

  for (iq in 1:numq){
    fin.se[iq] = sqrt(t(wtgd) %*% MatC[,,iq] %*% wtgd)
    fin.se.bma[iq] = sqrt(t(bmaw) %*% MatC[,,iq] %*% bmaw)
  }
  zz=list()
  zz$MatC = MatC
  zz$fin.se = fin.se; zz$fin.se.bma = fin.se.bma
  zz$numk = numk; zz$numq=numq; zz$wtgd=wtgd; zz$bmaw=bmaw
  return(zz)
}
