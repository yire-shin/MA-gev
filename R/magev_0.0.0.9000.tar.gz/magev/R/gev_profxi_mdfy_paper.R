gev.profxi.mdfy.paper=  function (data=NULL, mle=NULL, xlow, xup,
                                  pick.v = NULL, nint = 256, figure=F){

  w <- list();  v <- numeric(nint)

  w$fail=F; w$start='mle'

  conf = pick.v
  xlow.t= min(xlow, xup);    xup.t = max(xlow, xup)
  xlow= max(-0.9, xlow.t, na.rm=T);
  xup = min(0.9, xup.t, na.rm=T)
  x <- seq(xlow, xup, length.out = nint)
  sol <- c(mle[1], mle[2])      # mle = mle.coles

  #-------------------------------------------------------------
  gev.plikxi <- function(a, data=data, xi=xi) {

    if (a[2] <= 0) {
      l <- 10^6
      return(l)
    }
    if (abs(xi) < 10^(-6)) {
      y <- (data - a[1])/a[2]
      l <- length(y) * log(a[2]) + sum(exp(-y)) +
        sum(y)
    } else {
      y <- (data - a[1])/a[2]
      y <- 1 + xi * y
      if (any(y <= 0)) { l <- 10^6
      }else{ l <- length(y) * log(a[2]) + sum(y^(-1/xi)) +
        sum(log(y)) * (1/xi + 1)
      }
      l
    } #end if
  }
  #---------------------------------------------------------------
  for (i in 1:nint) {
    xi <- x[i]
    opt <- optim(sol, gev.plikxi, data=data, xi=xi)
    sol <- opt$par
    v[i] <- opt$value
  }
  for (i in 1:nint){
    if(v[i] >= 10^6) v[i]=NA }

  d <- data.frame(x=x,v=-v)  #%>% filter(v!=-10^6)
  d= na.omit(d)

  # ---------------------------------------------------------
  irt=0
  idmax = which.max(d$v)
  if(idmax==1 ) {

    irt=1
  }else if(idmax==length(d$x)){

    irt=1     # irt=1 means the max is observed at the first or the last x
  }

  if(irt==1) {
    w$start='lme'
    w$fail=T
    return(w)
  }

  #-----------------------------------------------------------
  port=1.3
  x0= min(d$x); x9 = max(d$x)
  bd0= max(0.2, abs(x0)) *sign(x0)
  bd9= max(0.2, abs(x9)) *sign(x9)

  xmin= min(-0.7, x0 - sign(x0)*port*bd0)
  xmax= max(0.7, x9 + sign(x9)*port*bd9)

  #  if(xmax < x9) no need to extrapol
  #  if(x0 < xmin) no need to extrapol

  inter=1

  #--- for linear interpolation ----------------------------------

  n.add= 32
  yleft=rep(NA, n.add);  yright=rep(NA, n.add)

  if(xmax > x9) {
    idmost= which.max(d$x)
    b.over= (d$v[idmost]-d$v[idmost-1])/(d$x[idmost]-d$x[idmost-1])
    extra.over= seq( d$x[idmost], xmax, by=(xmax-d$x[idmost])/n.add )

    b.over = b.over * 1.2

    for (i in 1:length(extra.over)){
      yright[i] = d$v[idmost] -b.over*(d$x[idmost]- extra.over[i])
    }
  }

  if(x0 > xmin) {
    idlst= which.min(d$x)
    b.bef= (d$v[idlst+1]-d$v[idlst])/(d$x[idlst+1]-d$x[idlst])
    extra.bef= seq(xmin, d$x[idlst], by=( d$x[idlst]-xmin)/n.add )

    b.bef = b.bef * 1.2

    for (i in 1:(length(extra.bef) ) ){
      yleft[i] = d$v[idlst] -b.bef*(d$x[idlst]- extra.bef[i])
    }
  }

  msp1 = data.frame(x= c(extra.bef, d$x, extra.over), y= c(yleft, d$v, yright) )
  dv1 = msp1$y

  w1= comp.prof.ci.new(d=msp1, v= dv1, conf=conf)

  #  --- end of linear interpolation  --------------------------------

  w$w1 = w1
  return(w)
}
