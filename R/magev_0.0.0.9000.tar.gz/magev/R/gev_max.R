gev.max=function (xdat, ntry=5)
{
  z <- list();  k =list()
  n=ntry

  nsample=length(xdat)
  z$nsample=nsample

  init= matrix(0, nrow=ntry, ncol=3)
  init <- ginit.max(xdat,ntry)
  upsig= sqrt(var(xdat))*5
  upmu=  abs(mean(xdat))*3

  #-------------------------------------------------
  gev.lik.max <- function(a) {

    mu <- a[1]      #mulink(mumat %*% (a[1:npmu]))
    sc <- a[2]      #siglink(sigmat %*% (a[seq(npmu + 1, length = npsc)]))
    xi <- a[3]      #shlink(shmat %*% (a[seq(npmu + npsc + 1, length = npsh)]))

    y <- (xdat - mu)/sc
    y <- 1 - xi * y        # park modify to negative, for xi in hosking

    for (i in 1:nsample){
      y[i] = max(0, y[i], na.rm=T) }

    if (any(y <= 0) || any(sc <= 0))
      return(10^6)

    if( abs(xi) >= 10^(-5) ) {ooxi= 1/xi
    }  else  {ooxi=sign(xi)*10^5}

    zz=nsample*(log(sc)) + sum( exp(ooxi *log(y)) ) + sum(log(y) * (1-(ooxi)) )

    return(zz)
  }
  #-------------------------------------------------------------
  tryCatch(
    for(i in 1:nrow(init)){

      value <- try(Rsolnp::solnp(init[i,], fun=gev.lik.max,
                         LB =c(-upmu,0,-1),UB =c(upmu,upsig,1),
                         control=list(trace=0, outer.iter=10,
                                      delta=1.e-6, inner.iter=200, tol=1.e-5) ))

      if(is(value)[1]=="try-error"){
        k[[i]] <- list(value=10^6)
      }else{
        k[[i]] <- value
      }

    } #for
  ) #tryCatch

  optim_value  <-data.frame(num=1:n,value=sapply(k, function(x) x$value[which.min(x$value)]))

  optim_table1 <-optim_value[order(optim_value$value),]
  selc_num  <- optim_table1[1,"num"]

  x  <-k[[selc_num]]

  #  mu <- x$par[1];  sc <- x$par[2];  xi <- x$par[3]

  z$conv <- x$convergence
  z$nllh <- x$value[which.min(x$value)]
  z$mle <- x$par

  return(z)
}
