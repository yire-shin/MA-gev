ginit.xifix <-function(data,ntry){

  initx <-matrix(0,nrow=ntry,ncol=2)

  lmom_init = lmomco::lmoms(data,nmom=5)
  lmom_est <- lmomco::pargum(lmom_init, checklmom=T )

  initx[1,1]    <- lmom_est$para[1]
  initx[1,2]    <- lmom_est$para[2]

  maxm1=ntry; maxm2=maxm1-1
  initx[2:maxm1,1] <- initx[1,1]+rnorm(n=maxm2,mean=0,sd = 7)
  initx[2:maxm1,2] <- initx[1,2]+rnorm(n=maxm2,mean=2,sd = 2)
  initx[2:maxm1,2] = max(0.1, initx[2:maxm1,2])

  return(initx)
}
