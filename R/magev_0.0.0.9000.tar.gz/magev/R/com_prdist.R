com.prdist = function(data, numk, kfix=NULL, Vinv=NULL, detV=NULL,
                      numom=NULL, hosking, trim=NULL, cov.type)
{
  weight = hosking$weight

  ww1=list(); kfix.lm=list()
  dd=matrix(NA, nrow=numom, ncol=2)
  gdd=matrix(NA, nrow=numk, ncol=2);  simple =rep(NA, numk)
  prob.mtx=matrix(NA, nrow=numk, ncol=2);

  #medata= median(data);
  re=sort(data); nsam=length(data)
  ntrim=trim

  lm = lmomco::lmoms(data,nmom=numom)
  #  lmtrim= lmoms(re[(ntrim+1):nsam], nmom=3)
  #  lmtrim = TLmoms(data,leftrim=trim, nmom=3)

  for (ip in 1:numk){

    if(kfix[[ip]]$conv != 0) {
      prob.mtx[ip,1:2]=0
      print(paste("No convergence in gev.xifix, ip=",ip))

    } else {
      if(kfix[[ip]]$mle[3] <=  -1.0) kfix[[ip]]$mle[3]= -0.999

      simple[ip] = kfix[[ip]]$mle[3]

      savek =lmomco::vec2par(kfix[[ip]]$mle,'gev')
      kfix.lm[[ip]]= lmomco::lmomgev(savek)       # mle[3] > -1

      #      kfix.lm[[ip]]= theoTLmoms(savek, leftrim=trim, nmom=3)
    }
  }  # end for ip

  # lmomgev(vec2par(c(100,30,-0.3),'gev'), leftrim=1)

  if(weight =='gLd'){

    for (ip in 1:numk){
      if(kfix[[ip]]$conv == 0){

        # xipar= kfix[[ip]]$mle[3]
        # if(xipar <= -0.4) {ntrim=trim+2
        # }else if(xipar <= -0.3) {ntrim=trim+1
        # }else{ ntrim= trim}
        #
        lmtrim.cvt= lmomco::lmoms(re[(ntrim+1):nsam], nmom=3)

        dd[1,1]= lmtrim.cvt$lambdas[1]- kfix.lm[[ip]]$lambdas[1]

        if(cov.type=='ratio'){
          dd[2:numom,1]= lmtrim.cvt$ratios[2:numom]- kfix.lm[[ip]]$ratios[2:numom]

        }else if(cov.type=='lambda'){
          dd[2,1]= lmtrim.cvt$lambdas[2]- kfix.lm[[ip]]$lambdas[2]
          dd[3,1]= lmtrim.cvt$lambdas[3]- kfix.lm[[ip]]$lambdas[3]
        }

        gdd[ip,1]= t(dd[1:numom,1])%*% Vinv %*% dd[1:numom,1]

        prob.mtx[ip,1]= exp(-gdd[ip,1]/2 )/( (2*pi)^(numom/2) * sqrt(detV) )

        if(is.na(prob.mtx[ip,1]) )  prob.mtx[ip,1]= 0
      }
    } #end for ip
  } #end if weight

  if(weight=='med') {

    for (ip in 1:numk){
      if( kfix[[ip]]$conv == 0){

        # xipar= kfix[[ip]]$mle[3]
        # if(xipar <= -0.4) {ntrim=trim+2
        # }else if(xipar <= -0.3) {ntrim=trim+1
        # }else{ ntrim= trim}
        #
        #         lmtrim= lmoms(re[(ntrim+1):nsam], nmom=3)

        medata = median(re[(ntrim+1):nsam])

        lmtrim.cvt= lmomco::lmoms(re[(ntrim+1):nsam], nmom=3)

        savek= lmomco::vec2par(kfix[[ip]]$mle,'gev')
        dd[1,2]= medata -lmomco::quagev(0.5, savek)

        if(cov.type=='ratio'){
          dd[2:numom,2]= lmtrim.cvt$ratios[2:numom]- kfix.lm[[ip]]$ratios[2:numom]

        }else if(cov.type=='lambda'){
          dd[2,2]= lmtrim.cvt$lambdas[2]- kfix.lm[[ip]]$lambdas[2]
          dd[3,2]= lmtrim.cvt$lambdas[3]- kfix.lm[[ip]]$lambdas[3]
        }

        gdd[ip,2]= t(dd[1:numom,2])%*% Vinv %*% dd[1:numom,2]

        prob.mtx[ip,2]= exp(-gdd[ip,2]/2 ) /( (2*pi)^(numom/2) * sqrt(detV) )

        if(is.na( prob.mtx[ip,2]) )  prob.mtx[ip,2]=0
      } #end if
    }  #end for ip =1, numk
  }   #end if med

  ww1$prob.mtx = prob.mtx
  ww1$gdd= gdd
  return(ww1)
}
