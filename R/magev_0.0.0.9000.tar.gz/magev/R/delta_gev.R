delta.gev = function(gevf3=NULL, mle3i=NULL, cov2i=NULL,
                     mle3j=NULL, cov2j=NULL,
                     quant=NULL, d3yes=F){

  z=list()
  numq=length(quant)
  # quant=.99 means T= 100 = 1/(1-quant) return period
  # gevf3  =list from gev.fit with mle.hosking
  # gevf2i,j =list from gev.fit(xi.fixed) with mle.hosking

  p= 1-quant
  yp= -log(1-p)

  if(d3yes==T){                  # d3yes =T for computing delta3 cov mtx
    c3 = gevf3$cov
    mle = gevf3$mle  #mle.hosking
    xi =  mle[3]
    sig = mle[2]
    d12= cbind(rep(1,numq), (1-yp^(xi))/xi )

    d3 = sig*(1-yp^(xi))/(xi^2) + sig * ( yp^(xi) ) * log(yp)/xi
    delta3 = cbind(d12, d3 )

    for(iq in 1:numq){
      z$v3[iq] = delta3[iq,] %*% c3 %*% delta3[iq,]
    }
    return(z)
    # z$v3 = asymptotic variance of zp from gev(theta hat):
    #                            without xi fixed
  }

  xi2i = mle3i[3] #gevf2i$mle[3]  # fixed xi_i
  xi2j = mle3j[3] #gevf2j$mle[3]  # fixed xi_j
  #    cov2i = cov2i #gevf2i$cov2[1:2,1:2]
  #    cov2j = cov2j #gevf2j$cov2[1:2,1:2]

  # --- compute correlation between i and j ------------------

  qqc= c(seq(0.1,0.9,0.1), 0.95, 0.98, 0.99, 0.995, 0.998, 0.999)
  zp.cori= lmomco::quagev(qqc,lmomco::vec2par(mle3i,'gev'))
  zp.corj= lmomco::quagev(qqc,lmomco::vec2par(mle3j,'gev'))
  corr.rt = cor(zp.cori, zp.corj)

  # xi= (xi2i +1)/2; xj= (xi2j +1)/2
  # corr.rt2= exp(-(xi-xj)^2 /2)

  covij=rep(NA, length(quant)); vi=rep(NA,numq); vj=rep(NA,numq)
  deltai=matrix(NA, 2,numq); deltaj=matrix(NA, 2,numq)

  for (id in 1:length(quant)){
    deltai[1:2,id]= c(1, (1-yp[id]^(xi2i))/xi2i)
    deltaj[1:2,id]= c(1, (1-yp[id]^(xi2j))/xi2j)

    vi[id] = t(deltai[,id]) %*% cov2i %*% deltai[,id]
    vj[id] = t(deltaj[,id]) %*% cov2j %*% deltaj[,id]

    covij[id] = corr.rt* sqrt(vi[id] * vj[id])
  }

  z$covij = covij
  # z$vi=vi; z$vj =vj
  return(z)
}
