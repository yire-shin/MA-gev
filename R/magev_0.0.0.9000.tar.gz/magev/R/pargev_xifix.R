pargev.xifix= function (lmom, xifix= 0.1, checklmom = TRUE, ...)
{

  para=rep(NA, 3)
  G=xifix
  para[3]= G

  if (length(lmom$lambdas[1]) == 0) {
    lmom <- lmorph(lmom)
  }

  SMALL <- 1e-05
  if( abs(G) < SMALL) {
    para[1:2]= pargum(lmom)$para
    return(list(type = "gev", para = para, source = "pargev"))
  }

  GAM <- exp(lgamma(1 + G))
  para[2] <- lmom$lambdas[2] * G/(GAM * (1 - 2^(-G)))
  para[1] <- lmom$lambdas[1] - para[2] * (1 - GAM)/G

  return(list(type = "gev", para = para, source = "pargev"))
}
