wlik.xifix = function(data,numk,kpar,weight, pertr,
                      varcom=F, type, eprior=NULL, trim=NULL){

  z=list()
  kfix=matrix(NA,nrow=3,ncol=numk);
  nbic=rep(NA,numk); bmin=rep(NA,numk)
  wt=rep(NA,numk); bmaw=rep(NA,numk); bmaw2=rep(NA,numk)
  para=rep(NA,3); lm3=list()
  re=sort(data); nsam=length(data)

  ntrim= trim  #max(trim-1,0)
  lmtrim= lmomco::lmoms(re[(ntrim+1):nsam], nmom=3)
  if(is.null(eprior)) eprior=1

  cov2.cv=list()

  for (ip in 1:numk){

    kfix[1:3,ip]= pargev.xifix(lmtrim, xifix=kpar[ip])$para[1:3]

    #    cat(trim, quagev(quant,vec2par(kfix[1:3,ip],'gev')),"\n")
    # }
    #   There is NO sig. diff. between trim=0 and trim=1

    if(varcom==T){
      Hess = PrescottW(as.vector( kfix[1:3,ip]), xifix=kpar[ip],
                       nsam=length(re[(ntrim+1):nsam]))

      if(is.na(Hess[1,1])) {
        cov2.cv[[ip]] = matrix(NA,2,2)
      }else if(det(Hess) <= 0) {
        cov2.cv[[ip]] = matrix(NA,2,2)
      }else{
        cov2.cv[[ip]] <- solve(Hess)
      }
    }

  } #end for ip

  prior = rcd(kpar)

  if(weight=='like'){
    for (ip in 1:numk){

      ntrim= trim
      dtrim=re[(ntrim+1):nsam]

      nbic[ip]= gev.xilik( kfix[1:2,ip], xifix= kpar[ip], xdat= dtrim )

      if(nbic[ip] >= 10^6)  nbic[ip]=NA
    } # end for ip

    numpar=2                      # Becoz xi fixed
    nbic = 2*nbic + 2*numpar      # AIC
    bmin = nbic -min(nbic, na.rm=T)
    wt =exp(-bmin)/sum(exp(-bmin), na.rm=T)
    #    for (ip in 1:numk){ if( is.na(wt[ip]) ) wt[ip]=0 }

    bmaw= prior*exp(-bmin)/sum(prior*exp(-bmin), na.rm=T)
    bmaw2= eprior*exp(-bmin)/sum(eprior*exp(-bmin), na.rm=T)

  }else if(weight=='lcv'){

    prob.mtx=rep(NA, numk)

    cvp = fcv.kfix.new(data,pertr,mle3=NULL,numk,kpar,
                       weight,type)

    prob.mtx= exp( cvp$prob )

    prob.mtx[which(is.na(prob.mtx))]=0
    if(all(prob.mtx==0)){
      prob.mtx= exp( cvp$prob/100 )/100
    }

    wt= prob.mtx[1:numk]/sum(prob.mtx, na.rm=T)

    bmaw = prior*prob.mtx[1:numk]/sum(prior*prob.mtx, na.rm=T)
    bmaw2 = eprior*prob.mtx[1:numk]/sum(eprior*prob.mtx, na.rm=T)

  }  #end if weight

  bmaw[which(is.na(bmaw))]=0;  bmaw2[which(is.na(bmaw2))]=0
  wt[which(is.na(wt))]=0

  z$bmaw=bmaw; z$wt= wt; z$bmaw2=bmaw2;
  z$aic= nbic
  z$kfix= kfix
  if(varcom==T){z$cov2 = cov2.cv}
  return(z)
}
