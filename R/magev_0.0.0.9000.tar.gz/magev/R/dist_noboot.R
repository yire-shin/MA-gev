dist.noboot = function(data, numk=NULL, hosking, boot.lme=T,
                       kpar=NULL, numom=NULL, ntry=5, varcom=T,
                       cov.lme, trim=NULL, cov.type='lambda'){

  cov2=list();  kfix=list();  zw=list()
  weight = hosking$weight
  B = hosking$B; if(boot.lme==TRUE) boot.lme=T

  mle3= matrix(NA, nrow=numk, ncol=3)
  lmB.med= rep(NA,B);   aic=rep(NA,numk)

  nsample= length(data)
  lm= lmomco::lmoms(data, nmom=numom)
  medata= median(data)

  # re=sort(data); nsam=length(data)
  # dtrim=re[(trim+1):nsam]

  #  if(weight=='lcv') varcoma=T

  for (ip in 1:numk){

    kfix[[ip]]= gev.xifix.sing(data, xifix=kpar[ip], ntry=ntry,
                               varcom=varcom)

    # cat(kpar[ip],quagev(c(.99,.995), vec2par(kfix[[ip]]$mle[1:3],'gev')),"\n")
    #   }


    if(kfix[[ip]]$conv != 0) {
      print(paste("No convergence in gev.xifix, ip=",ip))
      aic[ip]=NA
      mle3[ip,1:3]=NA
    }else{
      aic[ip]= 2*kfix[[ip]]$nllh + 2*2
      mle3[ip,1:3]= kfix[[ip]]$mle[1:3]
    }
    if(varcom==T) cov2[[ip]] = kfix[[ip]]$cov
  } #end for


  if( all(is.na(mle3[1:numk,1]) ) ){
    lm3=lmomco::lmoms(data, nmom=3)
    for(ip in 1:numk){
      mle3[ip,1:3] = pargev.xifix(lm3, xifix=kpar[ip])$para[1:3]
    }
  } #end if


  # if(weight=='lcv') {
  #   zw$cov2 = cov2
  #   zw$mle3= mle3
  #   return(zw)
  # }

  if(weight =='gLd'){

    if(cov.type=='ratio'){
      if(boot.lme==T){
        cov.lm = hosking$cov.rat
      }else{
        cov.lm = cov.lme$cov.rat
      }
    }else if(cov.type=='lambda'){
      if(boot.lme==T){
        cov.lm = hosking$cov.lambda
      }else{
        cov.lm = cov.lme$cov.lambda
      }
    }
    Vinv= solve(cov.lm)
    detV= det(cov.lm)

    zw$cov.lm=list(Vinv=Vinv, detV=detV)

  }   #end weight=gLd

  if(weight=='med'){

    if(cov.type=='ratio'){
      if(boot.lme==T){
        cov.med= hosking$cov.med.rat
      }else{
        cov.med= cov.lme$cov.med.rat
      }
    }else if(cov.type=='lambda'){
      if(boot.lme==T){
        cov.med= hosking$cov.med.lam
      }else{
        cov.med= cov.lme$cov.med.lam
      }
    }

    Vinv.med= solve(cov.med)
    detV.med= det(cov.med)

    Vinv=Vinv.med; detV=detV.med

    zw$cov.lm=list(Vinv=Vinv.med, detV=detV.med)

  }   # end if med

  if( weight == 'gLd' | weight =='med'){

    normal=list()
    normal$prob.mtx=matrix(NA, nrow=numk, ncol=2)

    normal= com.prdist(data, numk, kfix=kfix, Vinv=Vinv, detV=detV,
                       numom=numom, hosking, trim=trim, cov.type)

    for (ip in 1:numk){
      if( any( is.na(kfix[[ip]]$mle[1:3]) ) ) {
        mle3[ip,1:3]= NA
        normal$prob.mtx[ip,1:2] = 0.0
      }else{
        mle3[ip,1:3]= kfix[[ip]]$mle[1:3]  }            # end if
    }    # end for

  }     #end if weight =gLd or med

  if(weight=='fcv'){

    pertr=hosking$pertr

    fcvp =fcv.kfix.new(data,pertr,mle3=mle3,numk,kpar, cov2,
                       weight,type)
  }

  zw$aic= aic
  zw$mle3= mle3
  zw$kfix= kfix
  if(varcom==T) {zw$cov2 = cov2} else {zw$cov2 = NA}
  zw$prob.mtx= matrix(NA,numk, 3)

  if( weight == 'gLd' | weight =='med'){
    zw$prob.mtx= normal$prob.mtx
    zw$gdd= normal$gdd
  }else if(weight=='fcv') {
    zw$prob.mtx[1:numk,3]= exp( fcvp$prob[1:numk] )
    zw$cvp = fcvp$cvp
  }
  return(zw)
}
