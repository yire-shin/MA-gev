avar.ff.rl = function(mywt, covint, qqq=NULL,
                      hosking, numom=numom, consC.zp, order){

  zx=list()
  kpar= hosking$kpar; data =hosking$data; trim=hosking$trim
  wtgd= mywt$wtgd; bmaw = mywt$bmaw
  numq= length(qqq); numk = length(wtgd); cov.type=hosking$cov.type
  mywt2=list()

  mywt2 = weight.com.new(data,numk, hosking, kpar, numom=numom,
                         xqa=qqq, varcom=T, boot.lme, cov.lme,
                         surr=T, type="full", trim=trim, cov.type=cov.type)

  zp = mywt2$xzp
  consC.zp2 =list()

  consC.zp2 = cons.MatC(mywt2, covint, quant=qqq)

  # consC.zp2$fin.se
  # consC.zp2$fin.se.bma

  ezvar=rep(NA,numq); ewvar=rep(NA,numq); ewvar.bma=rep(NA,numq)
  trCD=rep(0, numq); trCD.bma=rep(0, numq)

  D = cov.dir(wtgd)
  Dbma = cov.dir(bmaw)

  move= movave(order, numk, numq, zp, wt=wtgd)
  ez=move$ez
  ew= move$ew

  moveb= movave(order, numk, numq, zp, wt=bmaw)
  ewbma= moveb$ew

  for(ip in 1:numq){
    ezvar[ip]= t(ez)[,ip] %*% D %*% ez[ip,]
    ewvar[ip]= t(ew) %*% consC.zp2$MatC[,,ip] %*% ew
    ewvar.bma[ip]= t(ewbma) %*% consC.zp2$MatC[,,ip] %*% ewbma

    trCD[ip]= sum( diag(consC.zp2$MatC[,,ip] %*% D) ) + ezvar[ip]
    trCD.bma[ip]= sum( diag(consC.zp2$MatC[,,ip] %*% Dbma) ) + ezvar[ip]
  }
  zx$adj.se.MA.qua = sqrt(ewvar + trCD )
  zx$adj.se.bma.qua = sqrt(ewvar.bma + trCD.bma)
  return(zx)
}
