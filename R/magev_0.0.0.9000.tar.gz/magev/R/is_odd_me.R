is.odd.me=function(x){
  return(ifelse(x%%2 == 1, TRUE, FALSE))
}
